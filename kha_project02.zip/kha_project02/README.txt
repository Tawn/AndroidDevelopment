Thanh Kha '19
Project02
Pooja Priya
Muhammed Ali Binici

ACADEMIC HONESTY PLEDGE:

I affirm that I did not give or receive any unauthorized help on this project, and that all work is my own.


ASSIGNMENT DESCRIPTION


This assignment has all the pieced needed to more than full credit, however, I am unfortunately running out of time. This project focuses much on SQLite databases; storing and retrieving data; with JQuery language. Additionally, we practiced the implementations of networking with other users, and also additional features such as the camera.


TESTING
	- Similar Instagram features, but top right corner button of (. . .) will send you 	  back a page, or log out from the feed and profile page. 
	
META REQUIREMENTS
	- New user is sent to the login screen with a sign in feature.
 	- User is able to log in and out.
	- Replicating the Instagram full features, orientations would stay portrait,
	  however, with persistent data with SQLite, state doesn’t change. 

ACCOUNT CREATION 
	- Fully Functional 
	- Username, Password, First, and Last name required.
	- Error messages if invalid inputs

PROFILE CREATION 
	- Photos are designated to user after taking first picture, unfortunately I just 	  got this feature to work, I have literally 24 min left :’(

SOCIAL NETWORKING 
	- All data is stored in SQLite database
	- All users can be viewed after logging in then swipe to go left
	- User is able to click on another user to view their profile

FEED
	- The Feed contains all the users but with their Profile pictures (which I ran out 	  of time doing).

ENHANCEMENTS (EXTRA CREDIT)


- Instagram Features:
	- layouts & Design
	- It’s very much like the real Instagram… if not, better!
	