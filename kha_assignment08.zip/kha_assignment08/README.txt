Thanh Kha '19
Assignment08
Pooja Priya
Muhammed Ali Binici

ASSIGNMENT DESCRIPTION

This assignment has us implement methods to read audio files from saving a path to the asset file. It also had us use the set-retain-instance to continue application of sound playing and text without interferrance. I have also created custom colors (6 total) for my application along with additional audio file (20 total). With that, I create custom layout and themes that changes the button press and shapes. 